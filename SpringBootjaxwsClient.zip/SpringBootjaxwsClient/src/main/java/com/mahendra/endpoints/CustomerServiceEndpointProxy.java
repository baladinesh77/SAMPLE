package com.mahendra.endpoints;

public class CustomerServiceEndpointProxy implements com.mahendra.endpoints.CustomerServiceEndpoint {
  private String _endpoint = null;
  private com.mahendra.endpoints.CustomerServiceEndpoint customerServiceEndpoint = null;
  
  public CustomerServiceEndpointProxy() {
    _initCustomerServiceEndpointProxy();
  }
  
  public CustomerServiceEndpointProxy(String endpoint) {
    _endpoint = endpoint;
    _initCustomerServiceEndpointProxy();
  }
  
  private void _initCustomerServiceEndpointProxy() {
    try {
      customerServiceEndpoint = (new com.mahendra.endpoints.CustomersLocator()).getCustomerServiceEndpointPort();
      if (customerServiceEndpoint != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)customerServiceEndpoint)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)customerServiceEndpoint)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (customerServiceEndpoint != null)
      ((javax.xml.rpc.Stub)customerServiceEndpoint)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.mahendra.endpoints.CustomerServiceEndpoint getCustomerServiceEndpoint() {
    if (customerServiceEndpoint == null)
      _initCustomerServiceEndpointProxy();
    return customerServiceEndpoint;
  }
  
  public com.mahendra.endpoints.Customer[] findByName(java.lang.String arg0) throws java.rmi.RemoteException{
    if (customerServiceEndpoint == null)
      _initCustomerServiceEndpointProxy();
    return customerServiceEndpoint.findByName(arg0);
  }
  
  public com.mahendra.endpoints.Customer findByEmail(java.lang.String arg0) throws java.rmi.RemoteException{
    if (customerServiceEndpoint == null)
      _initCustomerServiceEndpointProxy();
    return customerServiceEndpoint.findByEmail(arg0);
  }
  
  
}