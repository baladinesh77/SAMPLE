package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.mahendra.endpoints.Customer;
import com.mahendra.endpoints.CustomerServiceEndpoint;
import com.mahendra.endpoints.CustomerServiceEndpointProxy;

@SpringBootApplication
public class SpringBootjaxwsClientApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringBootjaxwsClientApplication.class, args);
	}
	
	@Bean
	public CustomerServiceEndpoint service1() {
		return new CustomerServiceEndpointProxy();
	}
	@Autowired CustomerServiceEndpoint service1;
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println("Invoking service...");
		Customer[] message = service1.findByName("Deepika");
		System.out.println("Message from service: "+message[0].getEmail());
		
	}



}
